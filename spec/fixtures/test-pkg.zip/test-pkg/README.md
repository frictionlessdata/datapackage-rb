Simple test package
